# -*- coding: utf-8 -*-
autyPath='/Users/tylan/Desktop/myAuty/Auty'